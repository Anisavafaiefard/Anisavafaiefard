﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication21
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            label10.Visible = false;
            label9.Visible = false;
            label8.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            richTextBox4.Visible = false;
            richTextBox5.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label6.Visible = false;
            label11.Visible = false;
            label7.Visible = false;
            label11.Visible  = false;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            label10.Visible =true;
            label9.Visible = true;
            label8.Visible = true;
            richTextBox1.Visible = true;
            richTextBox2.Visible = true;
            richTextBox3.Visible = true;
            richTextBox4.Visible = true;
            richTextBox5.Visible = false;
            label6.Visible =true;
            label5.Visible =false;
            label7.Visible = true;
            label11.Visible = false;
            label2.Visible=false ;
            richTextBox5.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            label10.Visible = false;
            label9.Visible = false;
            label8.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            richTextBox4.Visible = false;
            richTextBox5.Visible =true;
            label6.Visible = false;
            label5.Visible = false;
            label2.Visible = false;
            label11.Visible = true;
            richTextBox5.Visible = true;
            label12.Visible = true;
            label13.Visible = true;
            label14.Visible = true;
            label15.Visible = true;
            label6.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            label10.Visible = false;
            label9.Visible = false;
            label8.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            richTextBox4.Visible = false;
            label6.Visible = false;
            label11.Visible = false;
            richTextBox5.Visible = false;
           label5.Visible = true;
            label7.Visible = false;
            richTextBox5.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            label14.Visible = false;
            label15.Visible = false;
            label6.Visible = false;
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult ta = new DialogResult();
            ta = MessageBox.Show("آیا مطمئن هستید که میخواهید خارج شوید؟","اخطار",MessageBoxButtons.YesNo);
            if (ta == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
