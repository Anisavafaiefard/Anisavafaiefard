﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication21
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            pictureBox1.Visible = false;
            pictureBox3.Visible =false;
           label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            richTextBox3.Visible = false;
            pictureBox2.Visible = false;
            richTextBox2.Visible = false;
            lblMgMy.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
          
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void lblBRN_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = true;
            label7.Visible = true;
            label10.Visible = false;
            pictureBox1.Visible = false;
            pictureBox3.Visible = false;
            label8.Visible = false;
            richTextBox2.Visible = false;
            lblMgMy.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = false;
            pictureBox2.Visible = false;
            lblBasal.Visible = false;
            richTextBox3.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
            richTextBox2.Visible = true;
            richTextBox1.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = true;
            pictureBox3.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            lblMgMy.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            richTextBox3.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
            pictureBox2.Visible = false;

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = true;
            richTextBox3.Visible =true;
            label7.Visible = false;
            label8.Visible = false;
            richTextBox2.Visible = false;
            pictureBox1.Visible = false;
            label10.Visible = true;
            lblMgMy.Visible = false;
            pictureBox3.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;


        }

        private void label5_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            pictureBox1.Visible = false;
            label8.Visible = false;
            lblMgMy.Visible = false;
            lblPol.Visible = false;
            pictureBox2.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            pictureBox3.Visible = false;
            richTextBox3.Visible = false;
            label12.Visible = true;
            label13.Visible = false;
            richTextBox2.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = true;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
        }

        private void label14_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            pictureBox1.Visible = false;
            label8.Visible = false;
            pictureBox3.Visible = true;
            lblMgMy.Visible = false;
            lblPol.Visible = false;
            pictureBox2.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            richTextBox3.Visible = false;
            richTextBox2.Visible = false;
            label12.Visible = false;
            label13.Visible = true;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = true;
            rTbTala.Visible = false;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            lblMgMy.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = true;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            pictureBox2.Visible = false;
            richTextBox3.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
            pictureBox3.Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            lblMgMy.Visible = false;
            pictureBox3.Visible =true;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = true;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
            lblPol.Visible = true;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
        }

        private void label16_Click(object sender, EventArgs e)
        {
            lblMgMy.Visible = true;
            lblPol.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = false;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible =false;
            pictureBox3.Visible = true;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = true;
            pictureBox2.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible =false;
            rTbTala.Visible = false;
        }

        private void label17_Click(object sender, EventArgs e)
        {
            lblMgMy.Visible = false;
            pictureBox2.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = true;
            pictureBox3.Visible = false;
            lblBasal.Visible = false;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = true;
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

            lblMgMy.Visible = false;
            rTbBasal.Visible =true;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
            lblPol.Visible = false;
            pictureBox2.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible = true;
            pictureBox3.Visible =true;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            lblMgMy.Visible = false;
            lblPol.Visible = false;
            lblTala.Visible = false;
            lblBasal.Visible =false;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox2.Visible = false;
            richTextBox3.Visible = false;
            pictureBox2.Visible = false;
            label7.Visible = false;
            label10.Visible = false;
            label8.Visible = false;
            label12.Visible = false;
            label13.Visible = false;
            rTbBasal.Visible = false;
            rTbhypo.Visible = false;
            rTbMzMn.Visible = false;
            pictureBox3.Visible = false;
            rTbMzPol.Visible = false;
            rTbSaghe.Visible = false;
            rTbTala.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
         
        }

        private void rTbMzPol_TextChanged(object sender, EventArgs e)
        {

        }

        private void rTbSaghe_TextChanged(object sender, EventArgs e)
        {

        }

        private void rTbBasal_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult DR = new DialogResult();
            DR = MessageBox.Show("آیا مطمئن هستید که میخواهید خارج شوید؟", "اخطار", MessageBoxButtons.YesNo);
            if (DR == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
