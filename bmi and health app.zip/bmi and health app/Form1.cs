﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication21
            
{
   
    public partial class Form1 : Form
    {
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
        

        public Form1()
        {
            InitializeComponent();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
            richTextBox1.Visible = false;
            pictureBox3.Visible = false;
            gosh1.Visible = false;
            cheshm1.Visible = false;
            post.Visible = false;
            label6.Visible = false;
            pictureBox1.Visible = false;
            richTextBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            richTextBox2.Visible = false;
            richTextBox4.Visible = false;
            richTextBox5.Visible = false;
            pictureBox2.Visible = false;

        }

        private void label1_MouseClick(object sender, MouseEventArgs e)
        {

            
            richTextBox1.Visible = true;
            label6.Visible = true;
            pictureBox1.Visible = true;
            pictureBox3.Visible = false;
            richTextBox2.Visible = false;
            richTextBox5.Visible = false;
            richTextBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;
            richTextBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox2.Visible = false;
            cheshm1.Visible = true;
            gosh1.Visible = false;
            post.Visible = false;


        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
            label6.Visible = false;
            pictureBox1.Visible = false;
            richTextBox5.Visible = false;
            pictureBox3.Visible = false;
            richTextBox4.Visible = false;
            richTextBox3.Visible = false;
            pictureBox5.Visible = false;
            pictureBox4.Visible = false;
            richTextBox2.Visible = false;
            pictureBox2.Visible = false;
            pictureBox6.Visible = false;
            cheshm1.Visible = false;
            post.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();

            dr =MessageBox.Show("ایا مطمئن هستید که می خواهید خارج شوید؟", "اخطار", MessageBoxButtons.YesNo);
            if(dr==DialogResult.Yes)
            {
               Close();
            }
           
          
            
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void gharnie1_Click(object sender, EventArgs e)
        {

        }

        private void zojajie_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label3_MouseClick(object sender, MouseEventArgs e)
        {
            label6.Visible = true;
            richTextBox2.Visible = true;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            pictureBox3.Visible = false;
            pictureBox5.Visible = false;
            gosh1.Visible = true;
            post.Visible = false;
            pictureBox4.Visible = false;
            richTextBox5.Visible = false;
            pictureBox6.Visible = false;
            richTextBox4.Visible = false;
            richTextBox3.Visible = false;
            pictureBox2.Visible = true;
            cheshm1.Visible = false;
        }


        private void label2_MouseClick(object sender, MouseEventArgs e)
        {
            label6.Visible = true;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox3.Visible =true;
            richTextBox1.Visible = false;
            richTextBox5.Visible = false;
            richTextBox4.Visible = false;
            richTextBox2.Visible = false;
            pictureBox6.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = true;
            gosh1.Visible = false;
            post.Visible = false;
            pictureBox5.Visible = false;
            pictureBox4.Visible = false;
            cheshm1.Visible = false;
        }

        private void label9_MouseClick(object sender, MouseEventArgs e)
        {
            label6.Visible = true;
            pictureBox5.Visible =true;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox5.Visible = false;
            pictureBox6.Visible = true;
            richTextBox4.Visible = true;
            richTextBox3.Visible = false;
            pictureBox3.Visible = false;
            richTextBox2.Visible = false;
            pictureBox2.Visible = false;
            gosh1.Visible =false;
            pictureBox4.Visible = false;
            cheshm1.Visible = false;
        }

        private void label8_MouseClick(object sender, MouseEventArgs e)
        {
            label6.Visible = true;
            pictureBox1.Visible = false;
            richTextBox1.Visible = false;
            richTextBox5.Visible = true;
            richTextBox4.Visible = false;
            richTextBox3.Visible = false;
            pictureBox3.Visible = false;
            richTextBox2.Visible = false;
            pictureBox5.Visible = false;
            pictureBox2.Visible = false;
            pictureBox6.Visible = false;
            gosh1.Visible = false;
            post.Visible = true;
            pictureBox4.Visible = true;
            cheshm1.Visible = false;

        }

        private void richTextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(".تا حدالامکان از قرار گیری در محیط پرسرو صدا دوری کنید.2.صدای هدست و هدفون خود را در حد استاندارد نگه دارید3.گوش هایتان را در حمام تمیز کنید4 .به هیچ عنوان از اشیا تیز برای تمیز کردن گوش استفاده نکنید", "نکات مهم", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
        }

        private void cheshm1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("از مطالعه یا نگاه کردن به گوشی در نور کم پرهیز شود 2.مقابل افتاب از عینک افتابی استفاده شود.3.تا حد امکان از خیره به مانیتور دوری کنید4.استفاده همیشگی از مواد غذایی حاوی ویتامین آ فراموش نشود.5.از مالیدن چشم و فشار اضافی به چشم پرهیز کنید6.خواب و استراحت کافی فراموش نشود.", "نکات مهم", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            a++;
            if (a <= 10)
            {
                cheshm1.Left+= 2;
                cheshm1.BackColor = Color.OrangeRed;
           }
            if ((a >= 11) && (a <= 20))
            {
                cheshm1.Top += 2;
                cheshm1.BackColor = Color.Red;
            }
            if ((a >= 21) && (a <= 30))
            {
                cheshm1.Left-=2;
                cheshm1.BackColor = Color.OrangeRed;
            }
          
            
            if((a>=31)&&(a<=40))
            {
                cheshm1.Top -= 2;
                cheshm1.BackColor = Color.Red;
            }

            if (a == 41)
            {
                a = 0;
            }
            
          


        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            b++;
            if (b <= 10)
            {
               post.Left += 2;
                post.BackColor = Color.OrangeRed;
            }
            if ((b >= 11) && (b <= 20))
            {
               post.Top += 2;
                post.BackColor = Color.Red;
            }
            if ((b >= 21) && (b <= 30))
            {
                post.Left -= 2;
                post.BackColor = Color.OrangeRed;
            }


            if ((b >= 31) && (b <= 40))
            {
               post.Top -= 2;
                post.BackColor = Color.Red;
            }

            if (b == 41)
            {
                b = 0;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
           c++;
            if (c <= 10)
            {
             gosh1.Left += 2;
             gosh1.BackColor = Color.OrangeRed;
            }
            if ((c>= 11) && (c <= 20))
            {
               gosh1.Top += 2;
               gosh1.BackColor = Color.Red;
            }
            if ((c >= 21) && (c <= 30))
            {
                gosh1.Left -= 2;
              gosh1.BackColor = Color.OrangeRed;
            }


            if ((c >= 31) && (c <= 40))
            {
                gosh1.Top -= 2;
                gosh1.BackColor = Color.Red;
            }

            if (c == 41)
            {
                c = 0;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label11_MouseClick(object sender, MouseEventArgs e)
        {
            richTextBox1.Visible = false;
            label6.Visible = true;
            pictureBox1.Visible = false;
            richTextBox5.Visible = false;
            pictureBox3.Visible = true;
            richTextBox4.Visible = false;
            richTextBox3.Visible = true;
            pictureBox5.Visible = false;
            pictureBox4.Visible = false;
            richTextBox2.Visible = false;
            pictureBox2.Visible = false;
            pictureBox6.Visible = false;
            cheshm1.Visible = false;
            post.Visible = false;
            
        }

        private void richTextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void post_Click(object sender, EventArgs e)
        {
            MessageBox.Show(".از استحمام با اب داغ پرهیز کنید2.از ضد اقتاب استفاده کید3.رژیم غذایی سالم را از سر بگیرید.4.زخم های خود را هرگز نکنید", "نکات مهم", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            
        }

        private void label15_Click(object sender, EventArgs e)
        {
           Form3 d = new Form3();
            d.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Form2 m = new Form2();
            m.Show();
        }

        private void label10_Click_1(object sender, EventArgs e)
        {
            Form2 m = new Form2();
            m.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form10 D = new Form10();
            D.Show();
        }
    }
}
