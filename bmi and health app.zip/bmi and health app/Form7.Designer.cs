﻿namespace WindowsFormsApplication21
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.LBgardan = new System.Windows.Forms.Label();
            this.LBshekam = new System.Windows.Forms.Label();
            this.LBsine = new System.Windows.Forms.Label();
            this.LBjoloyebazo = new System.Windows.Forms.Label();
            this.LBsarshane = new System.Windows.Forms.Label();
            this.LBsaed = new System.Windows.Forms.Label();
            this.LBjoloran = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LBgardan
            // 
            this.LBgardan.BackColor = System.Drawing.Color.White;
            this.LBgardan.Location = new System.Drawing.Point(104, 57);
            this.LBgardan.Name = "LBgardan";
            this.LBgardan.Size = new System.Drawing.Size(43, 25);
            this.LBgardan.TabIndex = 0;
            this.LBgardan.Text = "گردن";
            this.LBgardan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBgardan.Visible = false;
            this.LBgardan.Click += new System.EventHandler(this.LBgardan_Click);
            // 
            // LBshekam
            // 
            this.LBshekam.BackColor = System.Drawing.Color.White;
            this.LBshekam.Location = new System.Drawing.Point(107, 165);
            this.LBshekam.Name = "LBshekam";
            this.LBshekam.Size = new System.Drawing.Size(43, 25);
            this.LBshekam.TabIndex = 1;
            this.LBshekam.Text = "شکم";
            this.LBshekam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBshekam.Visible = false;
            this.LBshekam.Click += new System.EventHandler(this.LBshekam_Click);
            // 
            // LBsine
            // 
            this.LBsine.BackColor = System.Drawing.Color.White;
            this.LBsine.Location = new System.Drawing.Point(107, 115);
            this.LBsine.Name = "LBsine";
            this.LBsine.Size = new System.Drawing.Size(43, 25);
            this.LBsine.TabIndex = 2;
            this.LBsine.Text = "سینه";
            this.LBsine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBsine.Visible = false;
            this.LBsine.Click += new System.EventHandler(this.LBsine_Click);
            // 
            // LBjoloyebazo
            // 
            this.LBjoloyebazo.BackColor = System.Drawing.Color.White;
            this.LBjoloyebazo.Location = new System.Drawing.Point(79, 140);
            this.LBjoloyebazo.Name = "LBjoloyebazo";
            this.LBjoloyebazo.Size = new System.Drawing.Size(89, 25);
            this.LBjoloyebazo.TabIndex = 3;
            this.LBjoloyebazo.Text = "جلو بازو";
            this.LBjoloyebazo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBjoloyebazo.Visible = false;
            this.LBjoloyebazo.Click += new System.EventHandler(this.LBjoloyebazo_Click);
            // 
            // LBsarshane
            // 
            this.LBsarshane.BackColor = System.Drawing.Color.White;
            this.LBsarshane.Location = new System.Drawing.Point(104, 82);
            this.LBsarshane.Name = "LBsarshane";
            this.LBsarshane.Size = new System.Drawing.Size(64, 25);
            this.LBsarshane.TabIndex = 4;
            this.LBsarshane.Text = "سرشانه";
            this.LBsarshane.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBsarshane.Visible = false;
            this.LBsarshane.Click += new System.EventHandler(this.LBsarshane_Click);
            // 
            // LBsaed
            // 
            this.LBsaed.BackColor = System.Drawing.Color.White;
            this.LBsaed.Location = new System.Drawing.Point(107, 201);
            this.LBsaed.Name = "LBsaed";
            this.LBsaed.Size = new System.Drawing.Size(43, 25);
            this.LBsaed.TabIndex = 5;
            this.LBsaed.Text = "ساعد";
            this.LBsaed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBsaed.Visible = false;
            this.LBsaed.Click += new System.EventHandler(this.LBsaed_Click);
            // 
            // LBjoloran
            // 
            this.LBjoloran.BackColor = System.Drawing.Color.White;
            this.LBjoloran.Location = new System.Drawing.Point(89, 290);
            this.LBjoloran.Name = "LBjoloran";
            this.LBjoloran.Size = new System.Drawing.Size(61, 25);
            this.LBjoloran.TabIndex = 6;
            this.LBjoloran.Text = "جلو ران";
            this.LBjoloran.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBjoloran.Visible = false;
            this.LBjoloran.Click += new System.EventHandler(this.LBjoloran_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(641, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "پایین کمر";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Visible = false;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(641, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "زیر بغل";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Visible = false;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(645, 116);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 25);
            this.label10.TabIndex = 9;
            this.label10.Text = "پشت بازو";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Visible = false;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(641, 91);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 25);
            this.label11.TabIndex = 10;
            this.label11.Text = "بالای کمر";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Visible = false;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(641, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 25);
            this.label12.TabIndex = 11;
            this.label12.Text = "کول";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Visible = false;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(641, 230);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 25);
            this.label13.TabIndex = 12;
            this.label13.Text = "باسن";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Visible = false;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(641, 302);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 25);
            this.label14.TabIndex = 13;
            this.label14.Text = "پشت ران";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Visible = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(354, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 23);
            this.label1.TabIndex = 14;
            this.label1.Text = "خوش آمدید";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(731, 593);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.LBjoloran);
            this.Controls.Add(this.LBsaed);
            this.Controls.Add(this.LBsarshane);
            this.Controls.Add(this.LBjoloyebazo);
            this.Controls.Add(this.LBsine);
            this.Controls.Add(this.LBshekam);
            this.Controls.Add(this.LBgardan);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MinimumSize = new System.Drawing.Size(180, 363);
            this.Name = "Form7";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ماهیچه ها و دستگاه حرکتی";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LBgardan;
        private System.Windows.Forms.Label LBshekam;
        private System.Windows.Forms.Label LBsine;
        private System.Windows.Forms.Label LBjoloyebazo;
        private System.Windows.Forms.Label LBsarshane;
        private System.Windows.Forms.Label LBsaed;
        private System.Windows.Forms.Label LBjoloran;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
    }
}