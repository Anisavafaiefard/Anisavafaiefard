﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication21
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void LBgardan_Click(object sender, EventArgs e)
        {
            Form8 K = new Form8();
            K.Show();
            //با کلیک روی لیبل گردن قرار هست فرم8 یا همان فرم مخصوص به تمرینات تقویت عضلات شانه نشان داده شود
        }

        private void LBsarshane_Click(object sender, EventArgs e)
        {
            Form9 L = new Form9();
            L.Show();
        }

        private void LBsine_Click(object sender, EventArgs e)
        {

        }

        private void LBjoloyebazo_Click(object sender, EventArgs e)
        {

        }

        private void LBshekam_Click(object sender, EventArgs e)
        {

        }

        private void LBsaed_Click(object sender, EventArgs e)
        {

        }

        private void LBjoloran_Click(object sender, EventArgs e)
        {

        }
    }
}
